
/********************************************************************************** 

**  Program Filename : main.cpp

**	Author: Woohyuk Yang

**  Date: May. 5th. 2016

** Description: CS162 ModE

** Input : 

** Output :  STD simulation 
************************************************************************************/

#include <iostream>

using namespace std;

class State
{
    private:
        State* next;
        int info;
    public:
        void SetInfo(int i)
        {
            info = i;
        }
        int GetInfo()
        {
            return info;
        }
        void SetNext(State* p)
        {
            next = p;
        }
        State* GetNext()
        {
            return this;
        }

};




int main()
{
#if 1
    State s[4];
//test
    for(int i = 0; i < 4; i++)
    {
        s[i].SetInfo(i);
      //  cout << s[i].GetInfo() << endl;
        s[i].SetNext(NULL);
    }
#endif
#if 0
   State *pHead = NULL;
   State *pCur = pHead; 
   pHead = &s[0];
   

int i = 0;
            while(pCur != NULL)
            {
               State *pCur = s[i].GetNext();
                pCur = &s[i+1];
                pCur = pCur->GetNext();
                i++;
            
            }
                State *pNext = s[4].GetNext();

                pNext = pHead;
#endif

#if 1
    
   State* pCur[4];

    for(int i = 0; i < 4; i++)
    {
    
//        pCur[i] = NULL;
        pCur[i] = s[i].GetNext();
        pCur[i] = &s[i+1];
    }

    pCur[3] = &s[0];


    for(int i = 0 ; i < 4; i++)
    {
        cout << pCur[i]->GetInfo() << endl;
        
    }





#endif
#if 0
/*printing info*/
            while(pCur != NULL)
            {
                
                pCur = pCur->GetNext();
                
                cout << "c" <<pCur->GetInfo() << endl;
                cout << "c" <<pCur->GetInfo() << endl;
                cout << "c" <<pCur->GetInfo() << endl;
                pCur = &s[i+1];
                
            }
 
#endif
    return 0;
}
