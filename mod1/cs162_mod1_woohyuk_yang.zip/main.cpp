/********************************************************************************** 

**  Program Filename : main.cpp

**	Author: Woohyuk Yang

**  Date: April. 29th. 2016

** Description: CS162 Mod1

** Input : 

** Output :  A menu the user can choose the function which the user wants to check. 
************************************************************************************/


#include "mymenu.hpp"

int main()
{

    ShowMenu();


    return 0;
}
