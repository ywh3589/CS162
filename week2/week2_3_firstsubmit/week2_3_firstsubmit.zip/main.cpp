#include "grid.hpp"

int main()
{
#if 0
    Critter ***pcritter = new Critter**[4];
        for(int i  = 0; i < 4; i++)
            critter[i] = new Critter*[2];
    
#endif
   // Critter critter;
    int a, b;
    cout << "a" << endl;
    cin >> a;
    cout << "b" << endl;
    cin >> b;

    Grid grid(a, b);
    
    




    return 0;
}
