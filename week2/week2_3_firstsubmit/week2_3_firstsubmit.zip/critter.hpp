#ifndef CRITTER_HPP
#define CRITTER_HPP
#include <iostream>

using namespace std;

class Critter
{
    private:
        int x;
        int y;

    public:
        Critter()
        {
            cout << "I am critter object" << endl;
        }





};

#endif
