//
//  file2.h
//  makeDemo
//
//  Created by Cierra Shawe on 6/23/15.
//  Copyright (c) 2015 Cierra Shawe. All rights reserved.
//

#ifndef __makeDemo__file2__
#define __makeDemo__file2__

#include <iostream>

void two();

#endif /* defined(__makeDemo__file2__) */
