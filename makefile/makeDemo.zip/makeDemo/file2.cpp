//
//  file2.cpp
//  makeDemo
//
//  Created by Cierra Shawe on 6/23/15.
//  Copyright (c) 2015 Cierra Shawe. All rights reserved.
//

#include "file2.h"

void two(){

    std::cout << "The ants go marching two by two...\n";

}