//
//  file1.cpp
//  makeDemo
//
//  Created by Cierra Shawe on 6/23/15.
//  Copyright (c) 2015 Cierra Shawe. All rights reserved.
//

#include "file1.h"

void one(){

    std::cout << "The ants go marching one by one...\n";
    
}