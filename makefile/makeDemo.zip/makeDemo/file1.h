//
//  file1.h
//  makeDemo
//
//  Created by Cierra Shawe on 6/23/15.
//  Copyright (c) 2015 Cierra Shawe. All rights reserved.
//

#ifndef __makeDemo__file1__
#define __makeDemo__file1__

#include <iostream>

void one();

#endif /* defined(__makeDemo__file1__) */
